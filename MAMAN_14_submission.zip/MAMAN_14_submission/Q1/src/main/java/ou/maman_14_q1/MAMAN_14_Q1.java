package ou.maman_14_q1;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

/**
 *
 * @author anatfradin
 */
public class MAMAN_14_Q1 {

    public static void main(String[] args) {
        
        System.out.println("**** Running String Test ****");
        System.out.println("\n >>> Result: " + TestString.runTest());
        
        System.out.println("\n*** Running Customer Test ****");
        System.out.println("\n >>> Result: " + TestCustomer.runTest());
        
    }
}
